const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/createLucideIcon-Bl9YB2nE.css"])))=>i.map(i=>d[i]);
import{r as u,c as R,j as g,a as Z}from"./createLucideIcon-DKceAhyd.js";const K=(function(){const t=typeof document<"u"&&document.createElement("link").relList;return t&&t.supports&&t.supports("modulepreload")?"modulepreload":"preload"})(),Q=function(e){return"/"+e},M={},G=function(t,r,s){let n=Promise.resolve();if(r&&r.length>0){let c=function(l){return Promise.all(l.map(p=>Promise.resolve(p).then(d=>({status:"fulfilled",value:d}),d=>({status:"rejected",reason:d}))))};document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),i=a?.nonce||a?.getAttribute("nonce");n=c(r.map(l=>{if(l=Q(l),l in M)return;M[l]=!0;const p=l.endsWith(".css"),d=p?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${d}`))return;const m=document.createElement("link");if(m.rel=p?"stylesheet":K,p||(m.as="script"),m.crossOrigin="",m.href=l,i&&m.setAttribute("nonce",i),document.head.appendChild(m),p)return new Promise((h,k)=>{m.addEventListener("load",h),m.addEventListener("error",()=>k(new Error(`Unable to preload CSS for ${l}`)))})}))}function o(a){const i=new Event("vite:preloadError",{cancelable:!0});if(i.payload=a,window.dispatchEvent(i),!i.defaultPrevented)throw a}return n.then(a=>{for(const i of a||[])i.status==="rejected"&&o(i.reason);return t().catch(o)})};let J={data:""},X=e=>{if(typeof window=="object"){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||J},ee=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,te=/\/\*[^]*?\*\/|  +/g,T=/\n+/g,w=(e,t)=>{let r="",s="",n="";for(let o in e){let a=e[o];o[0]=="@"?o[1]=="i"?r=o+" "+a+";":s+=o[1]=="f"?w(a,o):o+"{"+w(a,o[1]=="k"?"":t)+"}":typeof a=="object"?s+=w(a,t?t.replace(/([^,])+/g,i=>o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,c=>/&/.test(c)?c.replace(/&/g,i):i?i+" "+c:c)):o):a!=null&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),n+=w.p?w.p(o,a):o+":"+a+";")}return r+(t&&n?t+"{"+n+"}":n)+s},v={},F=e=>{if(typeof e=="object"){let t="";for(let r in e)t+=r+F(e[r]);return t}return e},re=(e,t,r,s,n)=>{let o=F(e),a=v[o]||(v[o]=(c=>{let l=0,p=11;for(;l<c.length;)p=101*p+c.charCodeAt(l++)>>>0;return"go"+p})(o));if(!v[a]){let c=o!==e?e:(l=>{let p,d,m=[{}];for(;p=ee.exec(l.replace(te,""));)p[4]?m.shift():p[3]?(d=p[3].replace(T," ").trim(),m.unshift(m[0][d]=m[0][d]||{})):m[0][p[1]]=p[2].replace(T," ").trim();return m[0]})(e);v[a]=w(n?{["@keyframes "+a]:c}:c,r?"":"."+a)}let i=r&&v.g?v.g:null;return r&&(v.g=v[a]),((c,l,p,d)=>{d?l.data=l.data.replace(d,c):l.data.indexOf(c)===-1&&(l.data=p?c+l.data:l.data+c)})(v[a],t,s,i),a},ae=(e,t,r)=>e.reduce((s,n,o)=>{let a=t[o];if(a&&a.call){let i=a(r),c=i&&i.props&&i.props.className||/^go/.test(i)&&i;a=c?"."+c:i&&typeof i=="object"?i.props?"":w(i,""):i===!1?"":i}return s+n+(a??"")},"");function _(e){let t=this||{},r=e.call?e(t.p):e;return re(r.unshift?r.raw?ae(r,[].slice.call(arguments,1),t.p):r.reduce((s,n)=>Object.assign(s,n&&n.call?n(t.p):n),{}):r,X(t.target),t.g,t.o,t.k)}let H,P,O;_.bind({g:1});let x=_.bind({k:1});function se(e,t,r,s){w.p=t,H=e,P=r,O=s}function E(e,t){let r=this||{};return function(){let s=arguments;function n(o,a){let i=Object.assign({},o),c=i.className||n.className;r.p=Object.assign({theme:P&&P()},i),r.o=/ *go\d+/.test(c),i.className=_.apply(r,s)+(c?" "+c:"");let l=e;return e[0]&&(l=i.as||e,delete i.as),O&&l[0]&&O(i),H(l,i)}return n}}var oe=e=>typeof e=="function",C=(e,t)=>oe(e)?e(t):e,ie=(()=>{let e=0;return()=>(++e).toString()})(),B=(()=>{let e;return()=>{if(e===void 0&&typeof window<"u"){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),ne=20,S="default",q=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(a=>a.id===t.toast.id?{...a,...t.toast}:a)};case 2:let{toast:s}=t;return q(e,{type:e.toasts.find(a=>a.id===s.id)?1:0,toast:s});case 3:let{toastId:n}=t;return{...e,toasts:e.toasts.map(a=>a.id===n||n===void 0?{...a,dismissed:!0,visible:!1}:a)};case 4:return t.toastId===void 0?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(a=>a.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let o=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+o}))}}},N=[],U={toasts:[],pausedAt:void 0,settings:{toastLimit:ne}},b={},V=(e,t=S)=>{b[t]=q(b[t]||U,e),N.forEach(([r,s])=>{r===t&&s(b[t])})},W=e=>Object.keys(b).forEach(t=>V(e,t)),le=e=>Object.keys(b).find(t=>b[t].toasts.some(r=>r.id===e)),A=(e=S)=>t=>{V(t,e)},ce={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},de=(e={},t=S)=>{let[r,s]=u.useState(b[t]||U),n=u.useRef(b[t]);u.useEffect(()=>(n.current!==b[t]&&s(b[t]),N.push([t,s]),()=>{let a=N.findIndex(([i])=>i===t);a>-1&&N.splice(a,1)}),[t]);let o=r.toasts.map(a=>{var i,c,l;return{...e,...e[a.type],...a,removeDelay:a.removeDelay||((i=e[a.type])==null?void 0:i.removeDelay)||e?.removeDelay,duration:a.duration||((c=e[a.type])==null?void 0:c.duration)||e?.duration||ce[a.type],style:{...e.style,...(l=e[a.type])==null?void 0:l.style,...a.style}}});return{...r,toasts:o}},ue=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:r?.id||ie()}),j=e=>(t,r)=>{let s=ue(t,e,r);return A(s.toasterId||le(s.id))({type:2,toast:s}),s.id},f=(e,t)=>j("blank")(e,t);f.error=j("error");f.success=j("success");f.loading=j("loading");f.custom=j("custom");f.dismiss=(e,t)=>{let r={type:3,toastId:e};t?A(t)(r):W(r)};f.dismissAll=e=>f.dismiss(void 0,e);f.remove=(e,t)=>{let r={type:4,toastId:e};t?A(t)(r):W(r)};f.removeAll=e=>f.remove(void 0,e);f.promise=(e,t,r)=>{let s=f.loading(t.loading,{...r,...r?.loading});return typeof e=="function"&&(e=e()),e.then(n=>{let o=t.success?C(t.success,n):void 0;return o?f.success(o,{id:s,...r,...r?.success}):f.dismiss(s),n}).catch(n=>{let o=t.error?C(t.error,n):void 0;o?f.error(o,{id:s,...r,...r?.error}):f.dismiss(s)}),e};var pe=1e3,me=(e,t="default")=>{let{toasts:r,pausedAt:s}=de(e,t),n=u.useRef(new Map).current,o=u.useCallback((d,m=pe)=>{if(n.has(d))return;let h=setTimeout(()=>{n.delete(d),a({type:4,toastId:d})},m);n.set(d,h)},[]);u.useEffect(()=>{if(s)return;let d=Date.now(),m=r.map(h=>{if(h.duration===1/0)return;let k=(h.duration||0)+h.pauseDuration-(d-h.createdAt);if(k<0){h.visible&&f.dismiss(h.id);return}return setTimeout(()=>f.dismiss(h.id,t),k)});return()=>{m.forEach(h=>h&&clearTimeout(h))}},[r,s,t]);let a=u.useCallback(A(t),[t]),i=u.useCallback(()=>{a({type:5,time:Date.now()})},[a]),c=u.useCallback((d,m)=>{a({type:1,toast:{id:d,height:m}})},[a]),l=u.useCallback(()=>{s&&a({type:6,time:Date.now()})},[s,a]),p=u.useCallback((d,m)=>{let{reverseOrder:h=!1,gutter:k=8,defaultPosition:z}=m||{},D=r.filter(y=>(y.position||z)===(d.position||z)&&y.height),Y=D.findIndex(y=>y.id===d.id),I=D.filter((y,L)=>L<Y&&y.visible).length;return D.filter(y=>y.visible).slice(...h?[I+1]:[0,I]).reduce((y,L)=>y+(L.height||0)+k,0)},[r]);return u.useEffect(()=>{r.forEach(d=>{if(d.dismissed)o(d.id,d.removeDelay);else{let m=n.get(d.id);m&&(clearTimeout(m),n.delete(d.id))}})},[r,o]),{toasts:r,handlers:{updateHeight:c,startPause:i,endPause:l,calculateOffset:p}}},fe=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,he=x`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ge=x`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,ye=E("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${fe} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${he} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${ge} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,be=x`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,ve=E("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${be} 1s linear infinite;
`,xe=x`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,we=x`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Ee=E("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${xe} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${we} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ke=E("div")`
  position: absolute;
`,je=E("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,$e=x`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Ne=E("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${$e} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Ce=({toast:e})=>{let{icon:t,type:r,iconTheme:s}=e;return t!==void 0?typeof t=="string"?u.createElement(Ne,null,t):t:r==="blank"?null:u.createElement(je,null,u.createElement(ve,{...s}),r!=="loading"&&u.createElement(ke,null,r==="error"?u.createElement(ye,{...s}):u.createElement(Ee,{...s})))},_e=e=>`
0% {transform: translate3d(0,${e*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,Ae=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${e*-150}%,-1px) scale(.6); opacity:0;}
`,De="0%{opacity:0;} 100%{opacity:1;}",Le="0%{opacity:1;} 100%{opacity:0;}",Pe=E("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Oe=E("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Re=(e,t)=>{let r=e.includes("top")?1:-1,[s,n]=B()?[De,Le]:[_e(r),Ae(r)];return{animation:t?`${x(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${x(n)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},Se=u.memo(({toast:e,position:t,style:r,children:s})=>{let n=e.height?Re(e.position||t||"top-center",e.visible):{opacity:0},o=u.createElement(Ce,{toast:e}),a=u.createElement(Oe,{...e.ariaProps},C(e.message,e));return u.createElement(Pe,{className:e.className,style:{...n,...r,...e.style}},typeof s=="function"?s({icon:o,message:a}):u.createElement(u.Fragment,null,o,a))});se(u.createElement);var ze=({id:e,className:t,style:r,onHeightUpdate:s,children:n})=>{let o=u.useCallback(a=>{if(a){let i=()=>{let c=a.getBoundingClientRect().height;s(e,c)};i(),new MutationObserver(i).observe(a,{subtree:!0,childList:!0,characterData:!0})}},[e,s]);return u.createElement("div",{ref:o,className:t,style:r},n)},Ie=(e,t)=>{let r=e.includes("top"),s=r?{top:0}:{bottom:0},n=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:B()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...s,...n}},Me=_`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,$=16,Te=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:s,children:n,toasterId:o,containerStyle:a,containerClassName:i})=>{let{toasts:c,handlers:l}=me(r,o);return u.createElement("div",{"data-rht-toaster":o||"",style:{position:"fixed",zIndex:9999,top:$,left:$,right:$,bottom:$,pointerEvents:"none",...a},className:i,onMouseEnter:l.startPause,onMouseLeave:l.endPause},c.map(p=>{let d=p.position||t,m=l.calculateOffset(p,{reverseOrder:e,gutter:s,defaultPosition:t}),h=Ie(d,m);return u.createElement(ze,{id:p.id,key:p.id,onHeightUpdate:l.updateHeight,className:p.visible?Me:"",style:h},p.type==="custom"?C(p.message,p):n?n(p):u.createElement(Se,{toast:p,position:d}))}))},Qe=f;const Fe=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],He=R("loader-circle",Fe);const Be=[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]],qe=R("refresh-cw",Be);const Ue=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],Ve=R("triangle-alert",Ue);class We extends u.Component{constructor(t){super(t),this.state={hasError:!1,error:null}}static getDerivedStateFromError(t){return{hasError:!0,error:t}}componentDidCatch(t,r){console.error("ErrorBoundary caught an error:",t,r)}handleReload=()=>{window.location.reload()};render(){return this.state.hasError?g.jsx("div",{className:"flex flex-col items-center justify-center min-h-screen bg-background text-foreground p-8",children:g.jsxs("div",{className:"bg-destructive/10 border border-destructive/30 rounded-xl p-8 max-w-md text-center",children:[g.jsx(Ve,{className:"w-16 h-16 text-destructive mx-auto mb-4"}),g.jsx("h1",{className:"text-xl font-bold mb-2",children:"Something went wrong"}),g.jsx("p",{className:"text-muted-foreground mb-6",children:this.state.error?.message||"An unexpected error occurred. Please try reloading the extension."}),g.jsxs("button",{onClick:this.handleReload,className:"inline-flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors",children:[g.jsx(qe,{className:"w-4 h-4"}),"Reload"]})]})}):this.props.children}}const Ye=u.lazy(()=>G(()=>import("./App-B_3nUoMb.js"),__vite__mapDeps([0])));function Ze(){return g.jsx("div",{className:"flex h-screen items-center justify-center bg-background",children:g.jsx(He,{className:"w-8 h-8 text-primary animate-spin"})})}Z.createRoot(document.getElementById("root")).render(g.jsxs(g.Fragment,{children:[g.jsx(Te,{position:"bottom-right"}),g.jsx(We,{children:g.jsx(u.Suspense,{fallback:g.jsx(Ze,{}),children:g.jsx(Ye,{})})})]}));export{He as L,qe as R,Ve as T,Qe as z};
